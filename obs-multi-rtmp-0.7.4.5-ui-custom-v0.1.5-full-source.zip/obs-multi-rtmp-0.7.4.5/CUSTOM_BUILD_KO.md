# OBS 다중 송출 UI 수정본 v0.1 — Windows 빌드 안내

## 반영된 UI 변경

- 송출 대상의 상태 점과 이름을 상단에 표시
- 활성화 체크박스와 시작/중지, 수정, 삭제 버튼을 상태 정보 바로 아래에 배치
- 송출시간과 비트레이트를 별도 라벨로 분리하고 크게/굵게 표시
- FPS는 같은 줄의 작은 보조 정보로 표시
- 모든 송출 대상 목록을 패널 상단에 배치
- `새 대상 추가`와 `모두 시작` / `모두 중지`를 대상 목록 아래쪽으로 이동
- 기존 송출 제어 로직과 설정 파일 형식은 변경하지 않음
- `buildspec.json`의 플러그인 버전은 0.7.4.5 그대로 유지

## Windows 설치 파일 생성

이 소스는 저장소의 기존 Windows 빌드 composite actions를 재사용하는 수동 실행 워크플로를 포함합니다.

1. GitHub 저장소의 **Actions** 탭을 엽니다.
2. **Build Customized Windows Plugin** 워크플로를 선택합니다.
3. **Run workflow**를 눌러 Windows x64 빌드를 시작합니다.
4. 성공한 실행 항목에서 Artifacts의 `obs-multi-rtmp-0.7.4.5-ui-custom-v0.1-windows-x64`를 다운로드합니다.
5. ZIP 또는 Installer EXE 중 하나를 사용합니다.

빌드 산출물은 이 소스 ZIP에 포함되어 있지 않습니다. Windows용 DLL과 설치 프로그램은 Windows runner에서 실제 빌드가 성공한 후에만 설치 가능한 것으로 간주해야 합니다.

## 설치 전 주의

- OBS를 종료하고 기존 플러그인 폴더를 백업하세요.
- 0.7.4.5 기준 수정본이므로 다른 플러그인 버전 위에 덮어쓰지 마세요.
- 기존 `obs-multi-rtmp.json` 설정 파일을 별도로 백업하세요.
- 설치 후 송출 대상 표시와 개별/전체 시작·중지 기능을 짧은 테스트 송출로 확인하세요.


## UI custom v0.1.4

- Backup-target time/bitrate/FPS/network statistics use larger fonts by default.
- A per-target `T` menu selects 100–160% text scale and remembers the selection in the user's Qt settings.
- Bitrate colors: 10 Mbps and above green; 5–10 Mbps yellow; below 5 Mbps red while live.
- FPS color is relative to the target's configured video FPS: 95% and above green; 80–95% yellow; below 80% red while live.
- Congestion title is white while idle and green while live; percentage and antenna bars use congestion severity colors.
- Dropped-frame text is white while idle/zero; during output it is green at zero, yellow for a small nonzero drop rate, orange from 0.10%, and red from 1.00%.
- Removed the default top margins from the target widget and dock list container.
- All statistics are read from each additional output. Main OBS stream monitoring is not modified.


## v0.1.5 로컬 통계 API

- 플러그인은 127.0.0.1:8766 에서 읽기 전용 HTTP 통계를 제공합니다.
- 브라우저 도크는 GET /multi-rtmp.json 으로 대상별 이름, 상태, 경과 시간, 비트레이트, FPS, RTMP 혼잡도, 드롭 프레임을 조회합니다.
- 응답에는 송출 URL, 스트림 키, 인코더 설정 또는 비밀번호를 포함하지 않습니다.
- 포트는 localhost에만 바인딩됩니다. 기본 방화벽 외부 접근을 허용할 필요가 없습니다.
