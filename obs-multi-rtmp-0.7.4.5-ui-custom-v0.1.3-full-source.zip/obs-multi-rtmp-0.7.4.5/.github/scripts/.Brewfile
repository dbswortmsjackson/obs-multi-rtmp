brew "coreutils"
brew "cmake"
brew "jq"
brew "xcbeautify"
